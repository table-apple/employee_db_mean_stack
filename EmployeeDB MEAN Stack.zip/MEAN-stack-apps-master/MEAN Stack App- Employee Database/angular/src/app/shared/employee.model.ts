export class Employee {
    _id: string;
    id: number;
    name: string;
    position: string;
    location: string;
    salary: number;
}
